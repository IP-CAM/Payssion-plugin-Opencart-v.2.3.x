<?php
require_once(realpath(dirname(__FILE__)) . "/payssion.php");

$_['heading_title']					= 'Turkish Credit/Bank Card (via Payssion)';
$_['text_payssionbankcardtr']		= '<a href="https://www.payssion.com" target="_blank"><img src="view/image/payment/bankcard_tr.png" alt="Payssion" title="Payssion" style="border: 1px solid #EEEEEE;" /></a>';