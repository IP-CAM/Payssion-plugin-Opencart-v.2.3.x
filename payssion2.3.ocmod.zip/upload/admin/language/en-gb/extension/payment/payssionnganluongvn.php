<?php
require_once(realpath(dirname(__FILE__)) . "/payssion.php");

$_['heading_title']					= 'Nganluong Vietnam (via Payssion)';
$_['text_payssionnganluongvn']		= '<a href="https://www.payssion.com" target="_blank"><img src="view/image/payment/nganluong_vn.png" alt="Payssion" title="Payssion" style="border: 1px solid #EEEEEE;" /></a>';