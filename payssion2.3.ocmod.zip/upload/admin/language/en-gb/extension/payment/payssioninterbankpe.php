<?php
require_once(realpath(dirname(__FILE__)) . "/payssion.php");

$_['heading_title']					= 'InterBank Peru (via Payssion)';
$_['text_payssioninterbankpe']		= '<a href="https://www.payssion.com" target="_blank"><img src="view/image/payment/interbank_pe.png" alt="Payssion" title="Payssion" style="border: 1px solid #EEEEEE;" /></a>';