<?php
require_once(realpath(dirname(__FILE__)) . "/payssion.php");

$_['heading_title']					= 'Bancontact (via Payssion)';
$_['text_payssionbancontactbe']		= '<a href="https://www.payssion.com" target="_blank"><img src="view/image/payment/bancontact_be.png" alt="Payssion" title="Payssion" style="border: 1px solid #EEEEEE;" /></a>';