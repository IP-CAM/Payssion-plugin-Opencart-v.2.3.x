<?php
require_once(realpath(dirname(__FILE__)) . "/payssion.php");

$_['heading_title']					= 'PromptPay (via Payssion)';
$_['text_payssionpromptpayth']		= '<a href="https://www.payssion.com" target="_blank"><img src="view/image/payment/promptpay_th.png" alt="Payssion" title="Payssion" style="border: 1px solid #EEEEEE;" /></a>';