<?php

require_once(realpath(dirname(__FILE__)) . "/payssion.php");
class ControllerExtensionPaymentPayssion7elevenmy extends ControllerExtensionPaymentPayssion {

}