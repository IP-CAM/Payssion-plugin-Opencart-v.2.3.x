<?php

require_once(realpath(dirname(__FILE__)) . "/payssion.php");
class ModelExtensionPaymentPayssion7elevenmy extends ModelExtensionPaymentPayssion {
}