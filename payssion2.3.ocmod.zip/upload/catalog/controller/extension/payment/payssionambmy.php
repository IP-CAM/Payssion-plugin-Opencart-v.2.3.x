<?php

require_once(realpath(dirname(__FILE__)) . "/payssion.php");
class ControllerExtensionPaymentPayssionAMBmy extends ControllerExtensionPaymentPayssion {
	protected $pm_id = 'amb_my';
}