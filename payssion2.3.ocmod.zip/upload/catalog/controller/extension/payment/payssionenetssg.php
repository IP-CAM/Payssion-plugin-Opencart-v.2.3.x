<?php

require_once(realpath(dirname(__FILE__)) . "/payssion.php");
class ControllerExtensionPaymentPayssionENetssg extends ControllerExtensionPaymentPayssion {
	protected $pm_id = 'enets_sg';
}