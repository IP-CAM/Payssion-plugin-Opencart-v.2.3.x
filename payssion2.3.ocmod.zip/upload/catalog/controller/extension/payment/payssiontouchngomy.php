<?php

require_once(realpath(dirname(__FILE__)) . "/payssion.php");
class ControllerExtensionPaymentPayssionTouchngomy extends ControllerExtensionPaymentPayssion {
    protected $pm_id = 'touchngo_my';
}