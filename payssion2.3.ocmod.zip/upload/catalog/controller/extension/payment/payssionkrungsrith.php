<?php

require_once(realpath(dirname(__FILE__)) . "/payssion.php");
class ControllerExtensionPaymentPayssionKrungsrith extends ControllerExtensionPaymentPayssion {
	protected $pm_id = 'krungsri_th';
}