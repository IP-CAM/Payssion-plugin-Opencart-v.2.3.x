<?php

require_once(realpath(dirname(__FILE__)) . "/payssion.php");
class ControllerExtensionPaymentPayssionBoostmy extends ControllerExtensionPaymentPayssion {
    protected $pm_id = 'boost_my';
}