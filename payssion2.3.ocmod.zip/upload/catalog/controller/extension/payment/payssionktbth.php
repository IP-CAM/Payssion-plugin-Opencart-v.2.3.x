<?php

require_once(realpath(dirname(__FILE__)) . "/payssion.php");
class ControllerExtensionPaymentPayssionKtbth extends ControllerExtensionPaymentPayssion {
	protected $pm_id = 'ktb_th';
}