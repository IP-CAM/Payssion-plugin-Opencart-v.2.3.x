<?php

require_once(realpath(dirname(__FILE__)) . "/payssion.php");
class ControllerExtensionPaymentPayssionPayupl extends ControllerExtensionPaymentPayssion {
    protected $pm_id = 'payu_pl';
}