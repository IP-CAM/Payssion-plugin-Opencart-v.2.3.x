<?php

require_once(realpath(dirname(__FILE__)) . "/payssion.php");
class ControllerExtensionPaymentPayssionPaybybankappgb extends ControllerExtensionPaymentPayssion {
    protected $pm_id = 'paybybank_gb';
}