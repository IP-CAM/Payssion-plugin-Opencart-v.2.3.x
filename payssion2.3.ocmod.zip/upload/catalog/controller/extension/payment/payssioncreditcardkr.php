<?php

require_once(realpath(dirname(__FILE__)) . "/payssion.php");
class ControllerExtensionPaymentPayssionCreditCardkr extends ControllerExtensionPaymentPayssion {
	protected $pm_id = 'creditcard_kr';
}