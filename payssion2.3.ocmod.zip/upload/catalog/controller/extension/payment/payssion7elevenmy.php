<?php

require_once(realpath(dirname(__FILE__)) . "/payssion.php");
class ControllerExtensionPaymentPayssion7elevenmy extends ControllerExtensionPaymentPayssion {
	protected $pm_id = '7eleven_my';
}