<?php

require_once(realpath(dirname(__FILE__)) . "/payssion.php");
class ControllerExtensionPaymentPayssionBitCashJP extends ControllerExtensionPaymentPayssion {
	protected $pm_id = 'bitcash_jp';
}